const Opsec = () => {
    let text = `This depends on what you do, see other edges as far as opsec considerations for activating roles`;
    return { __html: text };
};

export default Opsec;
