const References = () => {
    let text = ``;
    return { __html: text };
};

export default References;
