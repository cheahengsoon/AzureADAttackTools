const Opsec = () => {
    let text = `Azure will create a new log event for the key vault whenever a secret is accessed.`;
    return { __html: text };
};

export default Opsec;