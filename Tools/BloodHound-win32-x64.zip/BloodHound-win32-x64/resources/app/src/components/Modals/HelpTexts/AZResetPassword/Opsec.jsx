const Opsec = () => {
    let text = `Azure will log each password reset event, including who performed the reset, against which account, and at what date and time.`;
    return { __html: text };
};

export default Opsec;