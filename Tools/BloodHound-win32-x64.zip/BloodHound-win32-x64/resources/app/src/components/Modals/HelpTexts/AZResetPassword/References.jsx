const References = () => {
    let text = `<a href="https://powerzure.readthedocs.io/en/latest/Functions/operational.html#set-azureuserpassword">https://powerzure.readthedocs.io/en/latest/Functions/operational.html#set-azureuserpassword</a>`;
    return { __html: text };
};

export default References;
