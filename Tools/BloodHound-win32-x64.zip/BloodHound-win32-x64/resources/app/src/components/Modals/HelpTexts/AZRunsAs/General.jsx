import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `The Azure App runs as the Service Principal when it needs to authenticate to the tenant`;
    return { __html: text };
};

export default General;
