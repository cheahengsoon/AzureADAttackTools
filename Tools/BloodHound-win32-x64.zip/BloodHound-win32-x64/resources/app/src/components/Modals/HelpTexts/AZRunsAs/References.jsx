const References = () => {
    let text = `<a href="https://www.google.com">References go here</a>`;
    return { __html: text };
};

export default References;