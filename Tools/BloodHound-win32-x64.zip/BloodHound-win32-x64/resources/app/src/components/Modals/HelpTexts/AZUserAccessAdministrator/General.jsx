import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `The User Access Admin role can edit roles against many other objects`;
    return { __html: text };
};

export default General;
