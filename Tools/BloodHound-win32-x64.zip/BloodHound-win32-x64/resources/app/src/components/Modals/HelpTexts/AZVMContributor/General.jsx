import { groupSpecialFormat, typeFormat } from '../Formatter';

const General = (sourceName, sourceType, targetName, targetType) => {
    let text = `The Virtual Machine contributor role grants almost all abusable privileges against Virtual Machines.`;
    return { __html: text };
};

export default General;
