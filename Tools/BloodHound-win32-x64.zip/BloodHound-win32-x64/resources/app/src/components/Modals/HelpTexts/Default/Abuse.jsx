import { typeFormat } from '../Formatter';
const Abuse = (sourceName, sourceType, targetName, targetType) => {
    let text = ``;
    return { __html: text };
};
export default Abuse;
