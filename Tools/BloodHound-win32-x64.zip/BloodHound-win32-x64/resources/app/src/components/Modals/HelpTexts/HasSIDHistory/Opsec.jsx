const Opsec = () => {
    let text = `No opsec considerations apply to this edge.`;
    return { __html: text };
};

export default Opsec;
