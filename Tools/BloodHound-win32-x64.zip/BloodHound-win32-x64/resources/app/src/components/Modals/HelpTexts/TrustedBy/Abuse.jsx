import { typeFormat } from '../Formatter';
const Abuse = (sourceName, sourceType, targetName, targetType) => {
    let text = `There is no abuse associated with this edge.`;
    return { __html: text };
};

export default Abuse;
